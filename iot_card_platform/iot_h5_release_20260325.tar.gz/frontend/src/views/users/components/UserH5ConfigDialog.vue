<template>
  <el-dialog
    v-model="visible"
    title="H5配置"
    width="640px"
    :close-on-click-modal="false"
    @open="initForm"
  >
    <el-form label-width="110px">
      <el-form-item label="H5标题">
        <el-input v-model="form.title" maxlength="100" />
      </el-form-item>
      <el-form-item label="Logo地址">
        <el-input v-model="form.logo" maxlength="255" />
      </el-form-item>
      <el-form-item label="横幅图地址">
        <el-input v-model="form.banner" maxlength="255" />
      </el-form-item>
      <el-form-item label="公告文案">
        <el-input v-model="form.notice" type="textarea" :rows="3" maxlength="1000" show-word-limit />
      </el-form-item>
      <el-form-item label="客服电话">
        <el-input v-model="form.contact_phone" maxlength="30" />
      </el-form-item>
      <el-form-item label="客服微信">
        <el-input v-model="form.contact_wechat" maxlength="50" />
      </el-form-item>
      <el-form-item label="允许停机">
        <el-switch v-model="form.allow_suspend" />
      </el-form-item>
      <el-form-item label="允许复机">
        <el-switch v-model="form.allow_resume" />
      </el-form-item>
      <el-form-item label="允许备注">
        <el-switch v-model="form.allow_remark" />
      </el-form-item>
      <el-form-item label="需要验证">
        <el-switch v-model="form.require_verify" />
      </el-form-item>
      <el-form-item label="链接状态">
        <el-select v-model="form.status" style="width: 100%">
          <el-option label="启用" value="enabled" />
          <el-option label="停用" value="disabled" />
          <el-option label="过期" value="expired" />
        </el-select>
      </el-form-item>
    </el-form>

    <template #footer>
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" :loading="saving" @click="handleSubmit">
        保存
      </el-button>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { computed, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { userApi } from '@/api/modules/user'
import type { User, UserH5ConfigUpdateRequest } from '@/types/user'

interface Props {
  modelValue: boolean
  user: User | null
}

interface Emits {
  (e: 'update:modelValue', value: boolean): void
  (e: 'success'): void
}

const props = defineProps<Props>()
const emit = defineEmits<Emits>()

const visible = computed({
  get: () => props.modelValue,
  set: (value: boolean) => emit('update:modelValue', value)
})

const saving = ref(false)
const form = reactive<UserH5ConfigUpdateRequest>({
  title: '',
  logo: '',
  banner: '',
  notice: '',
  contact_phone: '',
  contact_wechat: '',
  allow_suspend: true,
  allow_resume: true,
  allow_remark: true,
  require_verify: false,
  status: 'enabled'
})

const initForm = () => {
  const h5 = props.user?.h5
  form.title = h5?.title || ''
  form.logo = h5?.logo || ''
  form.banner = h5?.banner || ''
  form.notice = h5?.notice || ''
  form.contact_phone = h5?.contact_phone || ''
  form.contact_wechat = h5?.contact_wechat || ''
  form.allow_suspend = h5?.allow_suspend ?? true
  form.allow_resume = h5?.allow_resume ?? true
  form.allow_remark = h5?.allow_remark ?? true
  form.require_verify = h5?.require_verify ?? false
  form.status = h5?.status || 'enabled'
}

const handleSubmit = async () => {
  if (!props.user?.id) return
  saving.value = true
  try {
    await userApi.updateH5Config(props.user.id, form)
    ElMessage.success('H5配置已保存')
    visible.value = false
    emit('success')
  } finally {
    saving.value = false
  }
}
</script>
